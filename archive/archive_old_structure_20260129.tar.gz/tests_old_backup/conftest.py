"""
pytest configuration for Intent Interface tests.

Adds src/ to sys.path so tests can import modules without src. prefix.
"""

import sys
from pathlib import Path

# Add src to path so imports work
src_path = Path(__file__).parent.parent / 'src'
sys.path.insert(0, str(src_path))




